#!/usr/bin/env bash
# deploy_vps.sh — 部署已编译的 xmonitor 静态二进制（无需 Go）
set -euo pipefail

BASE="$(cd "$(dirname "$0")" && pwd)"
USER=$(whoami)

echo "==> [1/3] 检查 xmonitor 二进制"
if [ ! -x "$BASE/xmonitor-linux-amd64" ]; then
  echo "ERROR: $BASE/xmonitor-linux-amd64 not found or not executable"
  exit 1
fi
# 使用正确的二进制名
if [ -f "$BASE/xmonitor-linux-amd64" ]; then
  BIN="$BASE/xmonitor-linux-amd64"
elif [ -f "$BASE/xmonitor-linux-arm64" ]; then
  BIN="$BASE/xmonitor-linux-arm64"
else
  BIN="$BASE/xmonitor"
fi
echo "    OK: $(du -h "$BIN" | cut -f1)"

# 修正 config.json：删除 proxy、调整路径
echo "==> [2/3] 修正 config.json"
python3 -c "
import json, sys
d = json.load(open(sys.argv[1]))
changed = []
if 'proxy' in d:
    d.pop('proxy')
    changed.append('删除 proxy')
json.dump(d, open(sys.argv[1], 'w'), ensure_ascii=False, indent=2)
print('    已修正: ' + '; '.join(changed))
" "$BASE/config.json"

# 安装 systemd 服务
echo "==> [3/3] 安装 systemd 服务"
sudo tee /etc/systemd/system/xmonitor.service >/dev/null <<EOF
[Unit]
Description=x-monitor (Go static binary)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=${USER}
WorkingDirectory=${BASE}
ExecStart=${BIN}
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable --now xmonitor.service
echo "    ✅ xmonitor.service 已启动"

echo ""
echo "部署完成！"
echo "  systemctl status xmonitor          # 状态"
echo "  journalctl -u xmonitor -e          # 日志"
echo "  $BIN --preview                     # 预览新闻"
