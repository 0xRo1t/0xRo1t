#!/usr/bin/env bash
# deploy_vps.sh — 在 Linux VPS 上一键部署 x-monitor（Go 静态编译版）
#
# 前置: 从 Mac 执行
#   rsync -avz ~/x-monitor/ user@VPS:~/x-monitor/
#   ssh user@VPS 'chmod +x ~/x-monitor/deploy_vps.sh && ~/x-monitor/deploy_vps.sh'
set -euo pipefail

BASE="$(cd "$(dirname "$0")" && pwd)"
SERVICE_USER="$(id -un)"

echo "==> [1/4] 检查 Go 和配置"
if ! command -v go >/dev/null 2>&1; then
  echo "    Go 未安装，尝试安装..."
  sudo apt-get update -qq
  sudo apt-get install -y -qq golang-go
fi
go version
echo "    Go OK"

# 编译 Go 二进制
echo "==> [2/4] 编译 xmonitor 二进制"
cd "$BASE/go"
go mod tidy 2>/dev/null || true
go build -ldflags="-s -w" -o "../xmonitor" .
echo "    已编译: $BASE/xmonitor ($(du -h "$BASE/xmonitor" | cut -f1))"

# 修正 config.json：删除 proxy、调整 x_bin 路径
echo "==> [3/4] 修正 config.json"
python3 -c "
import json
p = f'{sys.argv[1]}/config.json'
d = json.load(open(p))
changed = []
if 'proxy' in d:
    d.pop('proxy')
    changed.append('删除 proxy')
if d.get('x_bin'):
    old = d['x_bin']
    d['x_bin'] = f'{sys.argv[1]}/bin/x'
    changed.append(f'x_bin {old} -> {d[\"x_bin\"]}')
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
print('    已修正: ' + '; '.join(changed))
" "$BASE"

# 设置 systemd 服务（Go 单二进制，全部由一个服务接管）
echo "==> [4/4] 安装 systemd 服务"

sudo tee /etc/systemd/system/xmonitor.service >/dev/null <<EOF
[Unit]
Description=x-monitor (Go) — all services: monitor, news, bot, sentinel, snapshot, COT
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=${SERVICE_USER}
WorkingDirectory=${BASE}
ExecStart=${BASE}/xmonitor
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable --now xmonitor.service
echo "    xmonitor.service 已启动"

echo ""
echo "部署完成！常用命令:"
echo "  systemctl status xmonitor          # 状态"
echo "  journalctl -u xmonitor -e          # 日志"
echo "  ~/x-monitor/xmonitor --preview     # 预览新闻"
echo "  ~/x-monitor/xmonitor --list        # 监控账号列表"
echo "  ~/x-monitor/xmonitor --add <user>  # 添加监控"
echo ""
echo "提示: 如网络不稳可在 config.json 中保留 proxy 字段"
